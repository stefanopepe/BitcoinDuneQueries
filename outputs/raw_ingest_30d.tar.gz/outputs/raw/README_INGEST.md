# Raw Ingest Bundle (30d)

- Primary raw table: `borrow_events_30d.csv` / `.jsonl`
- Provenance: `manifest_borrow_events_30d.json` + SQL snapshot
- Cross-checks: `coverage_sanity_30d.csv`, `loop_significance_fast_30d.csv`