"""Alpen SIGNAL pipeline package."""
